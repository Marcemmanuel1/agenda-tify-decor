<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
require_once '../../includes/functions.php';

redirectIfNotLoggedIn();
if (!isSuperAdmin()) {
    header('Location: ../admin/');
    exit();
}

$db = getDB();
$message = '';

// Filtres et recherche
$filters = [
    'statut' => isset($_GET['statut']) ? $_GET['statut'] : '',
    'commune' => isset($_GET['commune']) ? $_GET['commune'] : '',
    'date_debut' => isset($_GET['date_debut']) ? $_GET['date_debut'] : '',
    'date_fin' => isset($_GET['date_fin']) ? $_GET['date_fin'] : '',
    'search' => isset($_GET['search']) ? $_GET['search'] : '',
    'planificateur' => isset($_GET['planificateur']) ? $_GET['planificateur'] : '',
    'agent' => isset($_GET['agent']) ? $_GET['agent'] : ''
];

// Construction de la requête avec filtres
$sql = "SELECT r.*, 
               c.nom as client_nom, c.prenom as client_prenom, c.commune, c.telephone,
               up.nom as planificateur_nom, up.prenom as planificateur_prenom,
               ua.nom as agent_nom, ua.prenom as agent_prenom
        FROM rendezvous r
        JOIN clients c ON r.client_id = c.id
        JOIN users up ON r.planificateur_id = up.id
        LEFT JOIN users ua ON r.agent_id = ua.id
        WHERE 1=1";

$params = [];

// Ajout des filtres
if (!empty($filters['statut'])) {
    $sql .= " AND r.statut_rdv = ?";
    $params[] = $filters['statut'];
}

if (!empty($filters['commune'])) {
    $sql .= " AND c.commune LIKE ?";
    $params[] = '%' . $filters['commune'] . '%';
}

if (!empty($filters['date_debut'])) {
    $sql .= " AND r.date_rdv >= ?";
    $params[] = date('Y-m-d', strtotime($filters['date_debut'])) . ' 00:00:00';
}

if (!empty($filters['date_fin'])) {
    $sql .= " AND r.date_rdv <= ?";
    $params[] = date('Y-m-d', strtotime($filters['date_fin'])) . ' 23:59:59';
}

if (!empty($filters['search'])) {
    $sql .= " AND (c.nom LIKE ? OR c.prenom LIKE ? OR c.telephone LIKE ? OR r.motif LIKE ?)";
    $search_term = '%' . $filters['search'] . '%';
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
}

if (!empty($filters['planificateur'])) {
    $sql .= " AND r.planificateur_id = ?";
    $params[] = $filters['planificateur'];
}

if (!empty($filters['agent'])) {
    $sql .= " AND r.agent_id = ?";
    $params[] = $filters['agent'];
}

$sql .= " ORDER BY r.date_rdv DESC";

// Exécution de la requête
$stmt = $db->prepare($sql);
$stmt->execute($params);
$rendezvous = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Récupérer les communes distinctes pour le filtre
$communes_stmt = $db->prepare("SELECT DISTINCT commune FROM clients ORDER BY commune");
$communes_stmt->execute();
$communes = $communes_stmt->fetchAll(PDO::FETCH_COLUMN);

// Récupérer les planificateurs
$planificateurs_stmt = $db->prepare("SELECT id, nom, prenom FROM users WHERE role = 'planificateur' ORDER BY nom, prenom");
$planificateurs_stmt->execute();
$planificateurs = $planificateurs_stmt->fetchAll(PDO::FETCH_ASSOC);

// Récupérer les agents
$agents_stmt = $db->prepare("SELECT id, nom, prenom FROM users WHERE role = 'agent' ORDER BY nom, prenom");
$agents_stmt->execute();
$agents = $agents_stmt->fetchAll(PDO::FETCH_ASSOC);

// Suppression d'un rendez-vous
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_rdv'])) {
    $rdv_id = filter_input(INPUT_POST, 'rdv_id', FILTER_VALIDATE_INT);
    $motif_suppression = filter_input(INPUT_POST, 'motif_suppression', FILTER_SANITIZE_STRING);
    
    if ($rdv_id && $motif_suppression) {
        try {
            $db->beginTransaction();
            
            // Log de la suppression
            $stmt = $db->prepare("INSERT INTO logs_suppression (rdv_id, user_id, motif_suppression) VALUES (?, ?, ?)");
            $stmt->execute([$rdv_id, $_SESSION['user_id'], $motif_suppression]);
            
            // Suppression du rendez-vous
            $stmt = $db->prepare("DELETE FROM rendezvous WHERE id = ?");
            $stmt->execute([$rdv_id]);
            
            $db->commit();
            $message = '<div class="alert success">Rendez-vous supprimé avec succès.</div>';
            
            // Recharger la liste
            header('Location: liste_rdv.php?success=1');
            exit();
        } catch (Exception $e) {
            $db->rollBack();
            $message = '<div class="alert error">Erreur lors de la suppression: ' . $e->getMessage() . '</div>';
        }
    } else {
        $message = '<div class="alert error">Veuillez saisir un motif de suppression.</div>';
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Rendez-vous - Administration</title>
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include '../../includes/header.php'; ?>
    <?php include 'header.php'; ?>
    
    <div class="main-content">
        <div class="page-header">
            <h1 class="page-title">Liste des Rendez-vous - Administration</h1>
        </div>
        
        <?php echo $message; ?>
        
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">Filtres de recherche</h2>
            </div>
            
            <form method="GET" class="filter-form">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
                    <div class="form-group">
                        <label for="statut">Statut</label>
                        <select id="statut" name="statut" class="form-control">
                            <option value="">Tous les statuts</option>
                            <option value="En attente" <?= $filters['statut'] == 'En attente' ? 'selected' : '' ?>>En attente</option>
                            <option value="Effectué" <?= $filters['statut'] == 'Effectué' ? 'selected' : '' ?>>Effectué</option>
                            <option value="Annulé" <?= $filters['statut'] == 'Annulé' ? 'selected' : '' ?>>Annulé</option>
                            <option value="Modifié" <?= $filters['statut'] == 'Modifié' ? 'selected' : '' ?>>Modifié</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="commune">Commune</label>
                        <select id="commune" name="commune" class="form-control">
                            <option value="">Toutes les communes</option>
                            <?php foreach ($communes as $commune): ?>
                            <option value="<?= htmlspecialchars($commune) ?>" <?= $filters['commune'] == $commune ? 'selected' : '' ?>>
                                <?= htmlspecialchars($commune) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="planificateur">Planificateur</label>
                        <select id="planificateur" name="planificateur" class="form-control">
                            <option value="">Tous les planificateurs</option>
                            <?php foreach ($planificateurs as $planificateur): ?>
                            <option value="<?= $planificateur['id'] ?>" <?= $filters['planificateur'] == $planificateur['id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($planificateur['prenom'] . ' ' . $planificateur['nom']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="agent">Agent</label>
                        <select id="agent" name="agent" class="form-control">
                            <option value="">Tous les agents</option>
                            <?php foreach ($agents as $agent): ?>
                            <option value="<?= $agent['id'] ?>" <?= $filters['agent'] == $agent['id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($agent['prenom'] . ' ' . $agent['nom']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="date_debut">Date début</label>
                        <input type="date" id="date_debut" name="date_debut" class="form-control" value="<?= htmlspecialchars($filters['date_debut']) ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="date_fin">Date fin</label>
                        <input type="date" id="date_fin" name="date_fin" class="form-control" value="<?= htmlspecialchars($filters['date_fin']) ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="search">Recherche</label>
                        <input type="text" id="search" name="search" class="form-control" placeholder="Nom, téléphone, motif..." value="<?= htmlspecialchars($filters['search']) ?>">
                    </div>
                </div>
                
                <div style="margin-top: 1rem; display: flex; gap: 1rem;">
                    <button type="submit" class="btn btn-primary">Filtrer</button>
                    <a href="liste_rdv.php" class="btn btn-secondary" style="text-decoration:none;">Réinitialiser</a>
                    <button type="button" id="export-btn" class="btn btn-secondary">Exporter</button>
                </div>
            </form>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">Rendez-vous (<?= count($rendezvous) ?>)</h2>
            </div>
            
            <?php if (count($rendezvous) > 0): ?>
            <div style="overflow-x: auto;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Client</th>
                            <th>Téléphone</th>
                            <th>Commune</th>
                            <th>Date RDV</th>
                            <th>Planificateur</th>
                            <th>Agent</th>
                            <th>Statut</th>
                            <th>Paiement</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rendezvous as $rdv): 
                            $statut_class = [
                                'En attente' => 'badge-warning',
                                'Effectué' => 'badge-success',
                                'Annulé' => 'badge-danger',
                                'Modifié' => 'badge-info'
                            ][$rdv['statut_rdv']];
                            
                            $paiement_class = $rdv['statut_paiement'] == 'Payé' ? 'badge-success' : 'badge-danger';
                        ?>
                        <tr>
                            <td><?= htmlspecialchars($rdv['client_prenom'] . ' ' . $rdv['client_nom']) ?></td>
                            <td><?= htmlspecialchars($rdv['telephone']) ?></td>
                            <td><?= htmlspecialchars($rdv['commune']) ?></td>
                            <td><?= date('d/m/Y H:i', strtotime($rdv['date_rdv'])) ?></td>
                            <td><?= htmlspecialchars($rdv['planificateur_prenom'] . ' ' . $rdv['planificateur_nom']) ?></td>
                            <td><?= $rdv['agent_id'] ? htmlspecialchars($rdv['agent_prenom'] . ' ' . $rdv['agent_nom']) : 'Non assigné' ?></td>
                            <td><span class="badge <?= $statut_class ?>"><?= $rdv['statut_rdv'] ?></span></td>
                            <td><span class="badge <?= $paiement_class ?>"><?= $rdv['statut_paiement'] ?></span></td>
                            
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div style="text-align: center; padding: 2rem;">
                <p>Aucun rendez-vous trouvé.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Modal de suppression -->
    <div id="deleteModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5); z-index: 1000;">
        <div style="background-color: white; width: 500px; margin: 100px auto; padding: 20px; border-radius: 8px;">
            <h2>Supprimer le rendez-vous</h2>
            <p>Vous êtes sur le point de supprimer le rendez-vous avec <strong id="delete-client-name"></strong>.</p>
            <p>Cette action est irréversible. Veuillez indiquer le motif de la suppression.</p>
            
            <form method="POST" id="deleteForm">
                <input type="hidden" name="rdv_id" id="delete-rdv-id">
                
                <div class="form-group">
                    <label for="motif_suppression">Motif de suppression *</label>
                    <textarea id="motif_suppression" name="motif_suppression" class="form-control" rows="4" required></textarea>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="document.getElementById('deleteModal').style.display = 'none'">Annuler</button>
                    <button type="submit" name="delete_rdv" class="btn btn-danger">Confirmer la suppression</button>
                </div>
            </form>
        </div>
    </div>
    
    <script src="../../js/script.js"></script>
    <script>
        // Gestion de la modal de suppression
        document.querySelectorAll('.delete-rdv').forEach(button => {
            button.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                const clientName = this.getAttribute('data-client');
                
                document.getElementById('delete-rdv-id').value = id;
                document.getElementById('delete-client-name').textContent = clientName;
                
                document.getElementById('deleteModal').style.display = 'block';
            });
        });
        
        // Export des données
        document.getElementById('export-btn').addEventListener('click', function() {
            // Récupérer les paramètres de filtrage actuels
            const params = new URLSearchParams(window.location.search);
            
            // Ouvrir une nouvelle fenêtre pour l'export
            window.open('export_rdv.php?' + params.toString(), '_blank');
        });
        
        // Fermer la modal en cliquant à l'extérieur
        document.getElementById('deleteModal').addEventListener('click', function(e) {
            if (e.target === this) {
                this.style.display = 'none';
            }
        });
    </script>
</body>
</html>