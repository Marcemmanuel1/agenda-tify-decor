<?php
require_once 'config/database.php';

function logHistorique($user_id, $action, $details) {
    $db = (new Database())->getConnection();
    $sql = "INSERT INTO historique (user_id, action, details, created_at) 
            VALUES (?, ?, ?, NOW())";
    $stmt = $db->prepare($sql);
    $stmt->execute([$user_id, $action, $details]);
    return $stmt->rowCount() > 0;
}

function getTodayBadgeages($user_id) {
    $db = (new Database())->getConnection();
    $today = date('Y-m-d');
    
    $sql = "SELECT * FROM badgeages 
            WHERE user_id = ? AND DATE(created_at) = ? 
            ORDER BY created_at DESC";
    $stmt = $db->prepare($sql);
    $stmt->execute([$user_id, $today]);
    
    $badgeages = ['arrival' => null, 'departure' => null];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        if ($row['type'] === 'arrival') {
            $badgeages['arrival'] = $row;
        } else {
            $badgeages['departure'] = $row;
        }
    }
    
    return $badgeages;
}

function calculateOvertime($departure_time) {
    $departure_hour = (int)date('H', strtotime($departure_time));
    
    if ($departure_hour >= 18 && $departure_hour < 20) {
        return 0; // Pas d'heures supp entre 18h et 20h
    } elseif ($departure_hour >= 20) {
        return $departure_hour - 18; // Heures supp après 20h
    }
    
    return 0; // Pas d'heures supp avant 18h
}

function isOnCompanyWifi() {
    $company_ip = '102.209.220.88';
    $user_ip = $_SERVER['REMOTE_ADDR'];
    return $user_ip === $company_ip;
}
?>