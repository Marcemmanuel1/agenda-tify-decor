<?php

// Afficher toutes les erreurs
error_reporting(E_ALL);

// Afficher les erreurs à l'écran
ini_set('display_errors', 1);

// Activer le reporting des erreurs pendant le développement
ini_set('display_startup_errors', 1);
session_start();
require_once '../../../config/db_connect.php';
require_once '../../../includes/auth.php';
require_once '../../../includes/functions.php';

// Vérifier si l'utilisateur est connecté
redirectIfNotLoggedIn();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <title>Badgeage Employé</title>
  <link rel="stylesheet" href="badgeage.css">
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="retour">
        <a href="../index.php"><i class="fas fa-arrow-left"></i> Retour</a>
      </div>
      <h1>Badgeage Employé</h1>
      <div class="wifi-status" id="wifiStatus">
        <i class="fas fa-wifi"></i>
        <span>Vérification du WiFi...</span>
      </div>
    </div>
    
    <div class="badge-container">
      <div class="badge-card" id="arriver-card">
        <div class="ripple-effect">
          <div class="ripple"></div>
          <div class="ripple"></div>
          <div class="ripple"></div>
        </div>
        <div class="badge-icon">
          <i class="fas fa-sign-in-alt"></i>
        </div>
        <h3>Arrivée</h3>
        <div class="badge-time" id="arrival-time"></div>
        <div class="status-badge" id="arrival-status">
          <i class="fas fa-check"></i>
        </div>
      </div>
      
      <div class="badge-card" id="depart-card">
        <div class="ripple-effect">
          <div class="ripple"></div>
          <div class="ripple"></div>
          <div class="ripple"></div>
        </div>
        <div class="badge-icon">
          <i class="fas fa-sign-out-alt"></i>
        </div>
        <h3>Départ</h3>
        <div class="badge-time" id="departure-time"></div>
        <div class="overtime-info" id="overtime-info"></div>
        <div class="status-badge" id="departure-status">
          <i class="fas fa-check"></i>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal pour le rapport facultatif -->
  <div class="modal" id="report-modal">
    <div class="modal-content">
      <div class="modal-header">
        <h2>Rapport de Fin de Journée</h2>
        <button class="close-modal">&times;</button>
      </div>
      <form id="report-form">
        <div class="form-group">
          <label for="observations">Observations et remarques</label>
          <div class="optional-note">(Facultatif)</div>
          <textarea id="observations" placeholder="Notez ici vos observations, incidents ou remarques concernant votre journée de travail..."></textarea>
        </div>
        <div class="modal-actions">
          <button type="button" class="btn btn-secondary" id="skip-report">Passer</button>
          <button type="submit" class="btn btn-primary">Soumettre</button>
        </div>
      </form>
    </div>
  </div>

  <div class="notification" id="notification"></div>

  <script src="badgeage.js"></script>
</body>
</html>